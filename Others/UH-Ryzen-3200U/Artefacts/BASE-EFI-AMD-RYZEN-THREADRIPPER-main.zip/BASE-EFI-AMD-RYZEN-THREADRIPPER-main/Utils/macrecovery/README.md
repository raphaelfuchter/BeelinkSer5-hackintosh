## macrecovery

macrecovery is a tool that helps to automate recovery interaction. It can be used to download diagnostics and recovery as well as analyse MLB.

Requires python3 to run. Run with `-h` argument to see all available arguments.

To create a disk image for a virtual machine installation use `build-image.sh`.

